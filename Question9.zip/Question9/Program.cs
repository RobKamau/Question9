﻿using System;

namespace Racing
{
    public class RacerEventArgs : EventArgs
    {
        public string RacerName { get; set; }
        public TimeSpan RaceTime { get; set; }

        public RacerEventArgs(string racerName, TimeSpan raceTime)
        {
            RacerName = racerName;
            RaceTime = raceTime;
        }
    }

    public delegate void RaceendedEventHandler(object sender, RacerEventArgs e);

    public class Race
    {
        public event RaceendedEventHandler Raceended;

        public void StartRace(string racerName)
        {
            Console.WriteLine($"Race started for {racerName}...");

            
            Random random = new Random();
            int duration = random.Next(20, 80);  // Random race duration between 30 and 120 seconds
            TimeSpan raceTime = TimeSpan.FromSeconds(duration);

            
            Console.WriteLine($"Racer {racerName} finished in {raceTime.TotalSeconds} seconds.");

           
            OnRaceended(new RacerEventArgs(racerName, raceTime));
        }

        protected virtual void OnRaceended(RacerEventArgs e)
        {
            Raceended?.Invoke(this, e);
        }
    }

    public class refereee
    {
        public void OnRaceended(object sender, RacerEventArgs e)
        {
            Console.WriteLine($"Race finished! Racer: {e.RacerName}, Time: {e.RaceTime.TotalSeconds} seconds.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            var race = new Race();

            var observer = new refereee();

            race.Raceended += observer.OnRaceended;

            race.StartRace("Mary");
            race.StartRace("Kiprono");
        }
    }
}
